module="inventory"
export FLASK_APP=$module
export FLASK_ENV=development

python3 -m flask run -h localhost -p 5000 >> /tmp/$module-api.log 2>&1 &
#python3 -m flask run -h localhost -p 5000


