import os,sys
from flask_restx import Namespace, Resource, fields
from flask import (request, current_app)
from werkzeug.utils import secure_filename
import datetime
import time
import subprocess
import json

api = Namespace("record", description="Record APIs")

search_model = api.model(
    'Record Search', {'query': fields.String(required=True, default="", description='Query string')}
)




@api.route('/search')
class RecordList(Resource):
    @api.doc('search_records')
    @api.expect(search_model)
    def post(self):
        req_obj = request.json
        res_obj = req_obj
        return res_obj

    @api.doc(False) 
    def get(self):
        return self.post()









